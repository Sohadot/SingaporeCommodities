from jinja2 import Template
import json, os

with open("data/cities.json") as f:
    cities = json.load(f)

with open("templates/base.html") as f:
    base = Template(f.read())

for city in cities:
    path = f"public/framework/{city['slug']}"
    os.makedirs(path, exist_ok=True)
    html = base.render(title=city["title"], content=city["thesis"])
    with open(f"{path}/index.html", "w") as out:
        out.write(html)

print("Build complete")
